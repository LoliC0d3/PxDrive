<?php

 $_USERS = array (
  0 => 
  array (
    'name' => 'ali',
    'pass' => '$1$PBGbrVlw$CYSpq4BwSIq.mjdl3ndsz.',
    'role' => 'superadmin',
  ),
  1 => 
  array (
    'name' => 'loli',
    'pass' => '$1$QPG68nZ0$RVc86QPditJam1zCmStjO/',
    'role' => 'user',
  ),
  2 => 
  array (
    'name' => 'miyuki',
    'pass' => '$1$c1WVY1ox$a1MkVouqWSdej0D6EEZjX0',
    'role' => 'admin',
  ),
);
